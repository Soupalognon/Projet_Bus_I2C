#define address_read 11010111
#define address_write 11010110
#define read 1
#define write 0

int main (void)
{
float value = 0;
float temp;

InitI2C();

char status;
unsigned char i2cbyte;

//Enable channel
//OpenI2C1( I2C_ON, I2C_BRG );
//TRSTAT=1;

//SlaveAddress_read = 11010111;
//SlaveAddress_write = 11010110;
IdleI2C();//wait for bus to be idle
WriteI2C(address_write);
ACKStatus();
WriteI2C(0b10101000); // Not sure this is right
ACKStatus();
IdleI2C();
RestartI2C();
WriteI2C(address_read);
ACKStatus();
rx_data[0]=getI2C();
printf(rx_data); //Call the UART to display
AckI2C();
//rx_data[0]=getI2C();
StopI2C();
IdleI2C();

}


